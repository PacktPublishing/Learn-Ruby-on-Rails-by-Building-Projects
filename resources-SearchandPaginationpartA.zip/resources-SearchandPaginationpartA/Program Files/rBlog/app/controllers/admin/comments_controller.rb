class Admin::CommentsController < Admin::ApplicationController
  def destroy
  end
end
