class Page < ActiveRecord::Base
	belongs_to :section
end
