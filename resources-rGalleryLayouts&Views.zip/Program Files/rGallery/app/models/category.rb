class Category < ActiveRecord::Base
	has_many :images
end
