class HomeController < ApplicationController
  def show
  end
end
