class Block < ActiveRecord::Base
end
