class ImagesController < ApplicationController
  def new
  end

  def create
  end

  def destroy
  end

  def index
  end
end
