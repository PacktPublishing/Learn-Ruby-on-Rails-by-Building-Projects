class Admin::CommentsController < ApplicationController
  def destroy
  end
end
