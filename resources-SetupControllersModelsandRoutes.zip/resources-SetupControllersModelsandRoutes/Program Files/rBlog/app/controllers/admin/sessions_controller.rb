class Admin::SessionsController < ApplicationController
  def new
  end

  def create
  end
end
