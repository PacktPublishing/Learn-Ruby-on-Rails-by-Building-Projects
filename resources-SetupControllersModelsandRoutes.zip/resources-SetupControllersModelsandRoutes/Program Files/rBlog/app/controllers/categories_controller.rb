class CategoriesController < ApplicationController
  def show
  end
end
