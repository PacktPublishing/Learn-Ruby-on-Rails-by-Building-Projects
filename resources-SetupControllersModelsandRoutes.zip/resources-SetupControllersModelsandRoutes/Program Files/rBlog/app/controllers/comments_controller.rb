class CommentsController < ApplicationController
  def new
  end
end
