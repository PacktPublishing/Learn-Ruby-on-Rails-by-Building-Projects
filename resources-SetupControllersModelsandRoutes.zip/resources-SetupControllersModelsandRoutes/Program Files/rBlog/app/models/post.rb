class Post < ActiveRecord::Base
end
