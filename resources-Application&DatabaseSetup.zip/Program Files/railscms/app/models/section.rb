class Section < ActiveRecord::Base
	has_many :pages
end
