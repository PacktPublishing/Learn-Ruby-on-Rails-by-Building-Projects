class Admin::SessionsController < Admin::ApplicationController
  def new
  end

  def create
  end
end
