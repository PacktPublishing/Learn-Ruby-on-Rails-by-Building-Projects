require 'test_helper'

class Admin::CategoriesHelperTest < ActionView::TestCase
end
